# 处理方法(自动生成草稿)

> ⚠ 本次运行为**模拟执行**(引擎缺失环境下的演示),所有数值均为结构演示值,不构成科学结论。

- 运行标识:`20260815T131122-39372778`
- 场景:quake
- 处理环境:Python 3.14.3 / win32
- 账本导出时间(UTC):2026-08-15T13:11:42Z

## 处理链

- **数据获取**(方法 `local_import`〔prov-1〕):使用 sentinel-1 影像 7 景(时间窗 2019-06-10..2019-08-15)〔prov-1〕,自本地既有产品目录导入(来源目录以执行记录为准)。
- 第 2–6 步(辅助数据、配准、干涉、滤波、解缠)由云端(ASF HyP3)标准流程完成,本地未重复执行;云端完成声明暂缺本地凭据(未找到 hyp3_manifest.json),证据阶梯已如实降级。
- **时序反演**(方法 `mintpy_sbas`〔prov-7〕):形变时序经 MintPy 小基线集(SBAS)方法反演〔ref:Berardino et al. (2002), IEEE TGRS 40(11):2375-2383;Yunjun et al. (2019), Comput. Geosci. 133:104331〕,网络构建方式 `small_baseline`〔prov-7〕〔ref:本项目配置;MintPy 官方主张宽松阈值 + 冗余网络(Yunjun et al. 2019 §6.3)〕,最大时间基线 120 天〔prov-7〕〔ref:Yunjun et al. (2019, Computers & Geosciences 133:104331, §6.3):推荐宽松阈值+冗余网络,MintPy tempBaseMax 默认不限(smallbaselineApp.cfg §2);同数据源对照:ASF HyP3+MintPy Ridgecrest 教程取 24 天(hyp3_insar_stack_for_ts_analysis.ipynb)、GMTSAR S1 教程 50 天;120 天属宽松侧,由数据驱动修剪兜底;跨冻融季场景须收紧(见 permafrost 场景包)(文献来源)〕;参考点选取未入账本,以 MintPy 运行配置为准(诚实缺席)。
- **误差校正**(方法 `tropo_era5_pyaps`〔prov-8〕):对流层延迟采用 ERA5 再分析资料经 PyAPS 校正〔ref:Jolivet et al. (2011), GRL 38, L17311;Jolivet et al. (2014), JGR 119:2324-2341〕;去斜方式 `no`〔prov-8〕〔ref:本项目配置;MintPy 注释:同震/震间等长波长信号不推荐 deramp(smallbaselineApp.cfg §9)〕;并作 DEM 误差校正〔ref:Fattahi & Amelung (2013), IEEE TGRS 51(7)〕;未启用固体潮校正。
- **形变模型**(方法 `step`〔prov-9〕):形变模型采用同震阶跃(Heaviside)拟合,避免把阶跃摊成虚假线性趋势,阶跃日期 20190706T0320〔prov-9〕〔ref:实测配置 RidgecrestSenDT71.txt(Ridgecrest 同震日);与 USGS 主震时刻 2019-07-06 03:19:53 UTC 一致(取整到分钟 T0320)(上游默认)〕。
- **出图导出**(方法 `figure_journal`〔prov-10〕):成图按期刊规格输出(600 dpi〔prov-10〕〔ref:本项目配置;期刊 combination art 惯例 500–600 dpi(Elsevier artwork sizing;AGU ≥300 dpi)〕,色标 `roma`〔prov-10〕〔ref:Crameri 科学色标家族(Crameri et al. 2020, Nat. Commun. 11:5444;发散数据 vmin/vmax 关于零对称)〕,格式 `png+pdf`〔prov-10〕〔ref:本项目配置;投稿交付矢量 PDF + 栅格 TIFF,Elsevier 明确不收 PNG(RESEARCH-pub-figures §1.2)〕)。
- **质检**(方法 `coherence_mask`〔prov-11〕):质检采用相干性掩膜检查〔prov-11〕(最弱质检形态,仅筛除低相干像元)。

## 质量指标与门禁

- 解缠有效覆盖率为 0.942〔prov-qa.json#unwrap_coverage〕,达到质量门要求(阈值 0.7〔ref:本项目从严的工程门,文献参照系:LiCSBAS 图级剔除线 unw_cov_thre=0.3(batch_LiCSBAS.sh 默认;Morishita et al. 2020, Remote Sens. 12(3):424 §2.4.1)是社区下限惯例;0.70 高于下限属主动加严,待 1 次实测标定后转 OK(若 warning 频繁可回退 0.3-0.5)(本地标定;PENDING 待标定)〕)。
- PS/SBAS 双链交叉验证相关系数为 0.92〔prov-qa.json#crossval_r〕,达到契约阈值 0.85〔ref:无文献先例(PS/SBAS 互检惯例用一对一速度差 std 表述而非相关系数):参照系为 Terrafirma 多处理器互检速度差 std 0.5-0.7 mm/yr 与 Glasgow S1 四方法互检 1.1 mm/yr(RSE 256:112306, 2021)、SBAS 速度精度 ~1 mm/yr(Casu et al. 2006, RSE 102:195-210);待 experiments/PENDING-crossval-calibration.md 标定,标定时须同时报告相关系数与速度差 std(本地标定;PENDING 待标定)〕。
- 双链重叠区速度差 RMSE 为 3.1 mm〔prov-qa.json#crossval_rmse_mm〕〔ref:多处理器互检惯例量级 0.5–1.1 mm/yr(Terrafirma;RSE 256:112306, 2021)——仅作量级对照,非达标判据〕。

| 指标 | 值 | 来源 | 重解析 |
|---|---|---|---|
| crossval_r | 0.92 | `qa.json#crossval_r` | ✓ |
| crossval_rmse_mm | 3.1 | `qa.json#crossval_rmse_mm` | ✓ |
| unwrap_coverage | 0.942 | `qa.json#unwrap_coverage` | ✓ |

> 重解析 ✓ = 该数字已从产物文件二次解析核对(不是从日志转述);指标之外的正文数字均直引 provenance。

## 图件引用

- 图 1(Figure 1 shows the exported product)取自产物 `products/figures`(art_id `figures`,第 10 步「出图导出」生成〔prov-10〕),指纹 `stat:v1:0ff41ecfd3969614…`,可据此核对图件与本账本的对应关系。

> 图内元素规范(参考点标记/色标单位与正方向/比例尺/经纬度轴)见 reference/RESEARCH-pub-figures-2026-08-12.md 的检查单。

## 证据边界

- 当前证据级别:**runnable**(阶梯:runnable → checked → audited → calibrated → validated → publishable)
- 无 GNSS/水准外部比对记录
- 封顶 runnable:模拟执行(引擎缺失),演示结果不构成证据
- 待标定阈值:corr_threshold, nan_fraction_below, unwrap_coverage(标定完成前证据级别封顶 audited)
- 尚未达到 checked(该级要求:全部步骤 run_ok 通过(执行与产物契约完整))。
- 尚未达到 audited(该级要求:产物指纹齐备且全部指标重解析一致(provenance 审计完整))。
- 尚未达到 calibrated(该级要求:外部比对指标(GNSS/水准,gnss_rmse_mm)入账)。
- 尚未达到 validated(该级要求:双链交叉验证(PS/SBAS)达契约阈值(且该阈值完成标定,非 PENDING))。
- 尚未达到 publishable(该级要求:跨环境复现记录与证据边界表)。
- 步骤证据来源:local 6 步、missing 5 步(逐步明细见 provenance.evidence.step_sources)
  - 第 2 步:云端完成声明缺本地证据:未找到 hyp3_manifest.json(云端完成声明缺本地证据)
  - 第 3 步:云端完成声明缺本地证据:未找到 hyp3_manifest.json(云端完成声明缺本地证据)
  - 第 4 步:云端完成声明缺本地证据:未找到 hyp3_manifest.json(云端完成声明缺本地证据)
  - 第 5 步:云端完成声明缺本地证据:未找到 hyp3_manifest.json(云端完成声明缺本地证据)
  - 第 6 步:云端完成声明缺本地证据:未找到 hyp3_manifest.json(云端完成声明缺本地证据)
- 本次为模拟执行:以上仅验证处理链结构与账本贯通性,不构成任何科学结论。

> 本节由 provenance 自动生成:「prov-N」样式引用指向第 N 步执行记录,「prov-产物#字段」样式指向指标来源产物,「ref:…」为文献/依据锚点;正文数字均可回溯到产物与命令轨迹。
