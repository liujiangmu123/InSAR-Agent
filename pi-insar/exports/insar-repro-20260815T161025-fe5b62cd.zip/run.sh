#!/usr/bin/env bash
# insar-agent 等价裸命令脚本 —— 按序拼接真实执行过的每步 cmd.sh
# run_id: 20260815T161025-fe5b62cd
# scenario: quake
# simulated: True
set -euo pipefail

# ── 第 1 步 · 数据获取 · method=local_import · state=done ──
# cwd: C:\Users\Administrator\AppData\Local\Temp\pi-insar-test-4v6mUn\sessions\pi-insar-it-15352
python .sim/s01.py

# ── 第 2 步 · 辅助数据 · method=dem_copernicus · state=skipped ──
# (跳过:云端(HyP3)已完成或人工跳过 —— 本地无等价命令)

# ── 第 3 步 · 配准 · method=isce2_tops_geom_esd · state=skipped ──
# (跳过:云端(HyP3)已完成或人工跳过 —— 本地无等价命令)

# ── 第 4 步 · 干涉 · method=isce2_ifg_multilook · state=skipped ──
# (跳过:云端(HyP3)已完成或人工跳过 —— 本地无等价命令)

# ── 第 5 步 · 滤波 · method=goldstein · state=skipped ──
# (跳过:云端(HyP3)已完成或人工跳过 —— 本地无等价命令)

# ── 第 6 步 · 解缠 · method=snaphu_mcf · state=skipped ──
# (跳过:云端(HyP3)已完成或人工跳过 —— 本地无等价命令)

# ── 第 7 步 · 时序反演 · method=mintpy_sbas · state=done ──
# cwd: C:\Users\Administrator\AppData\Local\Temp\pi-insar-test-4v6mUn\sessions\pi-insar-it-15352
python .sim/s07.py

# ── 第 8 步 · 误差校正 · method=tropo_era5_pyaps · state=done ──
# cwd: C:\Users\Administrator\AppData\Local\Temp\pi-insar-test-4v6mUn\sessions\pi-insar-it-15352
python .sim/s08.py

# ── 第 9 步 · 形变模型 · method=step · state=done ──
# cwd: C:\Users\Administrator\AppData\Local\Temp\pi-insar-test-4v6mUn\sessions\pi-insar-it-15352
python .sim/s09.py

# ── 第 10 步 · 出图导出 · method=figure_journal · state=done ──
# cwd: C:\Users\Administrator\AppData\Local\Temp\pi-insar-test-4v6mUn\sessions\pi-insar-it-15352
python .sim/s10.py

# ── 第 11 步 · 质检 · method=coherence_mask · state=done ──
# cwd: C:\Users\Administrator\AppData\Local\Temp\pi-insar-test-4v6mUn\sessions\pi-insar-it-15352
python .sim/s11.py

